#!/usr/bin/python3

import openrazer.client
devices = openrazer.client.DeviceManager().devices
for device in devices:
    if device.name == "Razer Naga Trinity":
        device.fx.static(255,0,0)
        device.dpi = (1350,1350)
