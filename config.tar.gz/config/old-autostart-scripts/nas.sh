#!/bin/bash

sshfs ivo@192.168.0.200:/mnt/NAS/ /mnt/nas

