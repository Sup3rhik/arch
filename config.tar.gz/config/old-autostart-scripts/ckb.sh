#!/bin/bash

/usr/bin/ckb-next --background

