#!/bin/bash

nvidia-settings -a [gpu:0]/GPUMemoryTransferRateOffset[3]=750
nvidia-settings -a [gpu:0]/GPUGraphicsClockOffset[3]=50
sudo nvidia-smi -pl 230
