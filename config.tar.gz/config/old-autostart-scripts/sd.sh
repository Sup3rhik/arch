#!/bin/bash

shutdown 01:00

